<?php
$route['dashboard'] 	=   "Dashboard";
?>