<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends MY_Controller {

    public function index()
    {
        // echo date("Y-m-d", strtotime("first day of previous month")).'<br />';
        // echo date("Y-m-d", strtotime("last day of previous month"));
        $hash = '$argon2i$v=19$m=1024,t=2,p=2$ei40RmRMVU1td2JPbmZaaQ$pc+nenrF8MAW30z+h7nxwQG47JeEt30fpt/oZTKZUgE';

		if (password_verify('1234', $hash)) {
		    echo 'Password is valid!';
		} else {
		    echo 'Invalid password.';
		}

    }

}

/* End of file Test.php */
