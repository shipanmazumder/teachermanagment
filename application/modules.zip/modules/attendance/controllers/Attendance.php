<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance extends MY_Controller {

	function __construct()
	{
		parent::__construct();
		/*
		|=============
		|	module load
		|=============
		*/
		$this->load->module('users');
		/*
		|===========
		|	check login && redirect
		|===========
		*/
		$this->users->_member_area();
		/*
		|=============
		|	model load
		|=============
        */
        $this->load->model('Attendance_model');
        
		/*
		|=============
		|	set header Cache control
		|=============
		*/
        
        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: " . gmdate( "D, j M Y H:i:s", time() ) . " GMT");
	}
	/*
	|====================
	|	default load
	|====================
	*/
	public function index()
	{
		redirect('dashboard','refresh');
    }
    /*
	|===========
	|	new attendance page load
	|===========
	*/
	public function add_attendance()
	{
        $data['main_content']='add_attendance';
        $data['all_batch']=$this->Attendance_model->view_all_running_batch();
		$this->load->view('page', $data);
    }
    /*
	|===============
	|	ajax search function
	|===============
	*/
	public function search_student($value='')
	{
        
        $batchid=$this->input->post('batch_id');
        $atten_count=$this->Attendance_model->check_attendance($batchid);
        $result=$this->Attendance_model->search_student($batchid);
        if(count($result)>0):
            ?>
			<form id="students_attendance_add" method="POST">
                <table id="students_table" class="table students_table mt-x" style="width: 100%">
                    <thead>
                        <tr class="data_row">
                            <td>Student ID</td>
                            <td>Name</td>
                            <td>Today<br>Attendance</td>
                            <td>Prev Month<br>Attendance</td>
                            <td>This Month<br>Attendance</td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i=0;
                        foreach ($result as $key=>$student_value):
                            $pre_attendance=$this->Attendance_model->previous_attendance($student_value->studentid);
                            $current_attendance=$this->Attendance_model->current_attendance($student_value->studentid);
                    ?>
                        <tr class="data_row">
                            <td><?= $student_value->student_id; ?></td>
                            <td><a href="<?= base_url(); ?>student/view-single-student/<?= $student_value->studentid;?>" class="text-info"><?= $student_value->student_name; ?></a></td>
                            <td>
                                <input type="hidden" name="id[]" id="id" value="<?= $i; ?>">
                                <input type="hidden" name="batch" id="batch" value="<?= $student_value->st_batch_id; ?>">
                                <input type="hidden" name="student[<?= $i; ?>]"  id="student" value="<?= $student_value->studentid; ?>">
                                <span class="checkbox">
                                    <label><input type="checkbox" name="std_atd[<?= $i; ?>]" id="std_atd"  value="P" > Present</label>
                                </span>
                            </td>
                            <td><span class="total_b_count"><?= @$pre_attendance; ?></span></td>
                            <td><span class="total_b_count"><?= @$current_attendance; ?></span></td>
                        </tr>
                    <?php
                        $i++;
                        endforeach;
                    ?>
                    </tbody>
                </table>
                <?php
                if($atten_count<=0):
                ?>
                 <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-3 mt-5">
                            <button onclick="update_data()" type="button" class="btn btn-success w-100 form-control save_attendance"  name="submit">Save Attendance</button>
                        </div>
                    </div>
                </div>
                <?php
                  endif;
                ?>
            </form>
            <?php
        else:
			?>
			<h6 class="text-center text-danger">No data available</h6>
            <?php
        endif;
    }
    /*
	|===============
	|	ajax  attendance add
	|===============
	*/
	public function add_attendance_data($value='')
	{
        $id=$_POST['id'];
        $today=date('y-m-d');
        foreach ($id as $key => $value) {
            if(isset($_POST['std_atd'][$value])==false)
            {
                $object=array(
                    'atten_batch_id' =>$_POST['batch'],
                    'atten_student_id' =>$_POST['student'][$value],
                    'atten_date' =>$today,
                    'atten_user_id' =>$this->users->getId(),
                    'present' =>'A',
                );
                $this->db->insert('attendance', $object);
                
            }
            else {
                 $object=array(
                    'atten_batch_id' =>$_POST['batch'],
                    'atten_student_id' =>$_POST['student'][$value],
                    'atten_date' =>$today,
                    'atten_user_id' =>$this->users->getId(),
                    'present' =>$_POST['std_atd'][$value],
                );
                $this->db->insert('attendance', $object);
            }
        }
        return true;
	}
    /*
	|===============
	|	view attendance
	|===============
	*/
	public function view_attendance($value='')
	{
        $data['main_content']='view_attendance';
        $data['all_batch']=$this->Attendance_model->view_all_running_batch();
		$this->load->view('page', $data);
	}
    /*
	|===============
	|	view attendance
	|===============
	*/
	public function view_student_attendance($value='')
	{
        $batchid=$this->input->post('batch_id');
        $atten_date=$this->input->post('atten_date');
       $result=$this->Attendance_model->view_student_attendance($batchid,$atten_date);
        if(count($result)>0):
            ?>
			<form id="students_attendance_add" method="POST">
                <table id="students_table" class="table students_table mt-x" style="width: 100%">
                    <thead>
                        <tr class="data_row">
                            <td>#</td>
                            <td>Student ID</td>
                            <td>Name</td>
                            <td>Attendance</td>
                            <td>Phone</td>
                            <td>Total Attendance</td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i=0;
                    $total_atten=0;
                        foreach ($result as $key=>$student_value):
                            $total_st_atten=$this->Attendance_model->view_student_total_attendance($student_value->studentid);
                    ?>
                        <tr class="data_row">
                            <td><?= ++$key; ?></td>
                            <td><?= $student_value->student_id; ?></td>
                            <td><a href="<?= base_url(); ?>student/view-single-student/<?= $student_value->atten_student_id;?>" class="text-info"><?= $student_value->student_name; ?></a></td>
                            <td><?= $student_value->present; ?></td>
                            <td><?= $student_value->student_mobile; ?></td>
                            <td><span class="total_b_count"><?= @$total_st_atten; ?>  </span></td>
                        </tr>
                    <?php
                        endforeach;
                    ?>
                    </tbody>
                </table>
            </form>
            <?php
        else:
			?>
			<h6 class="text-center text-danger">No data available</h6>
            <?php
        endif;
	}
}

/* End of file Attendance.php */
