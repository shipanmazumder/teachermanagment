<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance_model extends CI_Model {
	/*
	|======================
	|	@var error catch
	|======================
	*/
    public $someerror='';
    
   /*
	|==================
	|	view all running  batch
	|==================
	*/
	public function view_all_running_batch()
	{
		$this->db->select('*');
		$this->db->from('batch');
		$this->db->where('batch_status',"Running");
		$this->db->where('batch_user_id',$this->users->getId());
		$query=$this->db->get();
		return $query->result();
    }
    /*
	|==================
	|	search student
	|==================
	*/
    public function search_student($batchid)
    {
        $object=array(
            'st_batch_id'=>$batchid,
            'activity'=>'Active',
        );
       $query=$this->db->get_where('student',$object);
       return $query->result();
    }
    /*
	|==================
	|	check attendance
	|==================
	*/
    public function check_attendance($batchid)
    {
        $today=date('y-m-d');
        $this->db->select('*');
        $this->db->from('attendance');
        $this->db->where('atten_batch_id', $batchid);
        $this->db->where('atten_date', $today);
        return $this->db->get()->num_rows();
    }
    /*
	|==================
	|	view student attendance
	|==================
	*/
    public function view_student_attendance($batchid,$atten_date)
    {
        $this->db->select('*');
        $this->db->from('attendance');
        $this->db->join('student', 'attendance.atten_student_id = student.studentid', 'left');
        $this->db->where('attendance.atten_batch_id', $batchid);
        $this->db->where('attendance.atten_date', $atten_date);
        $query=$this->db->get();
        return $query->result();
    }
    /*
	|==================
	|	view student total attendance
	|==================
	*/
    public function view_student_total_attendance($studentid)
    {
        $this->db->select('*');
        $this->db->from('attendance');
        $this->db->where('atten_student_id', $studentid);
        $this->db->where('present', 'P');
        $query=$this->db->get();
        return $query->num_rows();
    }
    /*
	|==================
	|	count previous month student attendance
	|==================
	*/
    public function previous_attendance($studentid)
    {
        $first_day = date("Y-m-d", strtotime("first day of previous month"));
        $last_day  = date("Y-m-d", strtotime("last day of previous month"));
        $this->db->select('*');
        $this->db->from('attendance');
        $this->db->where('atten_date>=', $first_day);
        $this->db->where('atten_date<=', $last_day);
        $this->db->where('atten_student_id', $studentid);
        $this->db->where('present', "P");
        $query=$this->db->get();
        return $query->num_rows();
    }
    /*
	|==================
	|	count  current student attendance
	|==================
	*/
    public function current_attendance($studentid)
    {
        $today=date('Y-m-d');
        $first_day = date("Y-m-d", strtotime("first day of this month"));
        $this->db->select('*');
        $this->db->from('attendance');
        $this->db->where('atten_date>=', $first_day);
        $this->db->where('atten_date<=', $today);
        $this->db->where('atten_student_id', $studentid);
        $this->db->where('present', "P");
        $query=$this->db->get();
        return $query->num_rows();
    }
    
}

/* End of file Attendance_model.php */
