<?php
$route['attendance/add-attendance']="Attendance/add_attendance";
$route['attendance/search-student']="Attendance/search_student";
$route['attendance/add-attendance-data']="Attendance/add_attendance_data";
$route['attendance/view-attendance']="Attendance/view_attendance";
$route['attendance/view-student-attendance']="Attendance/view_student_attendance";