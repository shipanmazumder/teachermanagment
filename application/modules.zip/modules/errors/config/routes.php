<?php
$route['errors/not-found']= 'Errors';
?>