    <script src="<?php echo base_url(); ?>libs/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="<?php echo base_url(); ?>libs/js/vendor/jquery-3.2.1.min.js"></script>
    <!-- animsition js -->
    <script src="<?php echo base_url(); ?>libs/js/animsition.min.js"></script>
    <script src="<?php echo base_url(); ?>libs/js/plugins.js"></script>
    <script src="<?php echo base_url(); ?>libs/js/main.js"></script>
</body>

</html>
